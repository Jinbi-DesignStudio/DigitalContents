2030 FUTURE WORLD — TEAM 06 (2030 동묘시장 · MCU AI SOCIETY) 웹사이트
=====================================================================

[폴더 구조]  — 웹사이트 제작 가이드 2장 기준

2030-future-world/
├── index.html                 프로젝트 소개 페이지 (임시 — 수업에서 받은 페이지로 교체)
├── README.txt
└── TEAM06/
    ├── index.html             조 소개 페이지 (2030 동묘시장)
    ├── assets/
    │   ├── images/            team-hero.webp (메인 세계관 이미지, 2560px), logo.png (조 로고)
    │   ├── fonts/             Pretendard 글꼴 (오프라인용)
    │   ├── videos/            (비어 있음)
    │   └── models/            (비어 있음)
    ├── PRODUCT01/index.html   제품 소개 페이지 1
    ├── PRODUCT02/index.html   제품 소개 페이지 2
    ├── PRODUCT03/index.html   제품 소개 페이지 3
    └── PRODUCT04/index.html   제품 소개 페이지 4
        (각 PRODUCT 폴더 안 assets/images, videos, models 는 제품 에셋을 넣을 자리)
        PRODUCT04/assets/images/ : product-hero.webp (메인컷), product-rendering-main.webp,
                                   product-detail-01.webp, product-detail-02.webp


[여는 방법]

1) 간단히 보기
   - 압축을 푼 뒤 index.html 을 크롬/엣지/사파리로 열기
   - 인터넷 없이도 모든 페이지 이동·이미지·글꼴·지도 인터랙션이 동작함

2) 로컬 웹 서버로 보기 (가이드 권장 — 시연·최종 점검용)
   - 이 폴더(2030-future-world)에서 터미널을 열고 아래 명령 실행
       python -m http.server 8000
   - 브라우저에서 http://localhost:8000 접속
   - 또는 VS Code의 Live Server 확장으로 index.html 열기


[페이지 이동]

- 프로젝트 소개 → TEAM 06 카드
- 조 소개 페이지:  왼쪽 위 '전체 프로젝트'(홈 아이콘) → 프로젝트 소개
                   DONGMYO 로고 → 조 소개 페이지 맨 위
                   연관 제품 카드 / 지도 '상세 정보 바로 보기' → PRODUCT01~04
                   메인 이미지 아래 흐름 띠(01~04) → 각 섹션으로 이동
                   스크롤하면 오른쪽 아래 TOP 버튼 → 맨 위로
- 제품 소개 페이지: '전체 프로젝트'(홈 아이콘) → 프로젝트 소개
                   DONGMYO 로고 → TEAM 06 조 소개 페이지
                   오른쪽 섹션 번호(02~08) → 해당 섹션으로 이동
                   08 MORE FROM TEAM 06 → 다른 제품 페이지
                   오른쪽 아래 TOP 버튼 → 맨 위로
                   맨 아래 '← TEAM 06 · 2030 동묘시장으로 돌아가기'


[팀에서 채워야 할 곳]

- TEAM06/index.html 의 PRODUCTS 목록
    name / summary / detail : 제품명·설명
    features : 관련 장소 특징 번호 (예: [3,5]) — 비워두면 카드에 '입력 필요'로 표시
- PRODUCT01~04/index.html 의 NAMES : 제품명 (4개 파일 모두 같게)


[주의]

- 폴더 이름과 파일 이름(대소문자 포함)을 바꾸지 마세요. 링크가 끊겨요.
- 모든 링크는 상대 경로라 GitHub Pages / Netlify에 폴더째 올리면 그대로 동작해요.
- 제품 이미지·영상·3D 모델은 아직 없어서 회색 칸(자리 표시)으로 되어 있어요.
  각 PRODUCT 폴더의 assets 안에 파일을 넣고 연결하면 돼요.

[PRODUCT 4 내용 반영]
- 02~05 텍스트 입력 완료 (페르소나·문제·핵심 기능·인터랙션 플로우·사용 시나리오)
- TEAM06/PRODUCT04/assets/images/
  product-persona.webp      : 페르소나 (시나리오 03 컷에서 인물 부분을 자른 임시 이미지)
  product-feature-01~03.webp: 핵심 기능 01 들어 올림 / 02 빛·가격 표시 / 03 토글
  product-scene-01~04.webp  : 사용 시나리오 01~04
- 기능·시나리오 이미지를 클릭하면 크게 볼 수 있음 (Esc 또는 클릭으로 닫기)

[PRODUCT 4 · 3D 뷰어]
- 06 Product Design 메인 칸 = 3D 뷰어 (드래그: 돌려 보기, 휠: 확대·축소, '처음 시점' 버튼)
- TEAM06/PRODUCT04/assets/models/
  tag.glb        : 원본 GLB (보관용)
  tag-model.js   : 뷰어가 실제로 읽는 파일 (원본을 세운 자세로 변환·압축, 더블클릭으로 열어도 작동)
- 모델을 못 불러오는 환경에서는 기존 렌더 이미지가 그대로 보임
- 원본은 바닥에 누운 상태 → 뷰어에서 세우고 스트랩을 뒤로 휘어 넘긴 모양으로 보여줌 (원본 GLB 파일은 그대로)

[PRODUCT 4 제품 정보]
- 제품명: AI 빈티지 디스커버리 태그 / 핵심 문장: 들어 올리는 순간, 물건의 가치가 보인다.
- 반영 위치: PRODUCT 4 페이지 맨 위, 모든 제품 페이지의 08 다른 제품 보기,
  조 페이지 연관 제품 카드(한 줄 설명 = 핵심 문장), 3D 지도 정보 박스(설명 = 상세 정보)
